let isDarkMode = false;

function showContact() {
  alert("📧 Email: chinrarui01@gmail.com\n📞 Phone: 064-5536922");
}

